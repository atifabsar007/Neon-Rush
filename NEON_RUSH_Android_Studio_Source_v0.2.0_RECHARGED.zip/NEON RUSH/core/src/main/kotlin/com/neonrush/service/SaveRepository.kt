package com.neonrush.service

import com.badlogic.gdx.Gdx

/** Preferences are private to the app and available entirely offline. */
class SaveRepository {
    private val prefs = Gdx.app.getPreferences("neon_rush_preferences")
    var soundEnabled: Boolean
        get() = prefs.getBoolean("soundEnabled", true)
        set(value) { prefs.putBoolean("soundEnabled", value).flush() }

    var musicEnabled: Boolean
        get() = prefs.getBoolean("musicEnabled", true)
        set(value) { prefs.putBoolean("musicEnabled", value).flush() }

    var bestScore: Int
        get() = prefs.getInteger("bestScore", 0)
        private set(value) { prefs.putInteger("bestScore", value).flush() }

    fun recordScore(score: Int): Boolean {
        if (score <= bestScore) return false
        bestScore = score
        return true
    }
}
