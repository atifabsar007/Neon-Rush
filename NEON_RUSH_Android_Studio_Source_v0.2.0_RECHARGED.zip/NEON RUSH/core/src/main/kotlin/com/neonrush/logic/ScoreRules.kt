package com.neonrush.logic

/** Pure, platform-independent rules: safe to test on the JVM. */
object ScoreRules {
    const val POINTS_PER_ORB = 75
    fun score(distanceMeters: Float, collectedOrbs: Int): Int =
        distanceMeters.toInt().coerceAtLeast(0) + collectedOrbs.coerceAtLeast(0) * POINTS_PER_ORB

    fun speed(elapsedSeconds: Float): Float = (285f + elapsedSeconds.coerceAtLeast(0f) * 8f).coerceAtMost(650f)

    fun obstacleInterval(elapsedSeconds: Float): Float =
        (1.35f - elapsedSeconds.coerceAtLeast(0f) * 0.009f).coerceAtLeast(0.62f)
}
