package com.neonrush.render

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.utils.Disposable
import com.badlogic.gdx.utils.viewport.Viewport
import com.neonrush.logic.RunSession
import kotlin.math.cos
import kotlin.math.sin

/** Procedural neon art style with no third-party textures. */
class NeonPainter : Disposable {
    private val shapes = ShapeRenderer()
    private val batch = SpriteBatch()
    private val font = BitmapFont()
    private val glyph = GlyphLayout()
    private val cyan = Color(0.15f, 0.96f, 1f, 1f)
    private val pink = Color(1f, 0.23f, 0.66f, 1f)
    private val purple = Color(0.60f, 0.45f, 1f, 1f)
    private val white = Color(0.95f, 0.98f, 1f, 1f)
    private val muted = Color(0.63f, 0.71f, 0.82f, 1f)
    private val lime = Color(0.55f, 1f, 0.62f, 1f)
    private var worldTime = 0f

    fun prepare(viewport: Viewport, delta: Float) {
        worldTime += delta.coerceIn(0f, 0.05f)
        viewport.apply()
        shapes.projectionMatrix = viewport.camera.combined
        batch.projectionMatrix = viewport.camera.combined
        Gdx.gl.glClearColor(0.015f, 0.02f, 0.06f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)
    }

    fun beginShapes() {
        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        shapes.begin(ShapeRenderer.ShapeType.Filled)
    }

    fun endShapes() { shapes.end(); Gdx.gl.glDisable(GL20.GL_BLEND) }
    fun beginText() { batch.begin() }
    fun endText() { batch.end() }

    fun text(value: String, x: Float, y: Float, scale: Float = 1.6f, color: Color = white, centered: Boolean = false) {
        font.data.setScale(scale)
        font.color = color
        if (centered) {
            glyph.setText(font, value)
            font.draw(batch, value, x - glyph.width / 2f, y)
        } else font.draw(batch, value, x, y)
    }

    fun backdrop(scroll: Float = worldTime * 45f) {
        shapes.setColor(0.03f, 0.045f, 0.11f, 1f)
        shapes.rect(0f, 0f, 480f, 800f)

        shapes.setColor(0.04f, 0.10f, 0.22f, 0.65f)
        shapes.rect(0f, 450f, 480f, 350f)
        shapes.setColor(0.13f, 0.20f, 0.36f, 0.25f)
        shapes.rect(0f, 410f, 480f, 80f)

        for (i in 0..19) {
            val x = 8f + i * 24f
            val height = 75f + ((i * 37) % 160)
            shapes.setColor(0.04f, 0.06f, 0.16f, 1f)
            shapes.rect(x, 430f, 19f, height)
            for (j in 0 until height.toInt() / 24) {
                val alpha = if ((i + j) % 3 == 0) 0.26f else 0.10f
                shapes.setColor(0.20f, 0.84f, 1f, alpha)
                shapes.rect(x + 4f, 440f + j * 18f, 3f, 6f)
            }
        }

        val sunY = 635f
        shapes.setColor(pink.r, pink.g, pink.b, 0.22f)
        shapes.circle(372f, sunY, 72f, 40)
        shapes.setColor(0.95f, 0.52f, 0.90f, 0.55f)
        shapes.circle(372f, sunY, 50f, 40)
        shapes.setColor(0.16f, 0.16f, 0.32f, 1f)
        for (i in 0..4) shapes.rect(322f, 618f + i * 11f, 100f, 5f)

        for (i in -1..16) {
            val y = 425f + ((i * 45f - (scroll * 0.35f % 45f)) + 45f) % 720f
            shapes.setColor(0.2f, 0.65f, 1f, 0.07f)
            shapes.rect(68f, y, 344f, 1.2f)
        }

        for (i in 0..28) {
            val x = ((i * 131) % 480).toFloat()
            val y = 500f + ((i * 219 + 77) % 290).toFloat()
            val a = 0.08f + 0.10f * (1f + sin(worldTime * 1.8f + i))
            shapes.setColor(0.78f, 0.9f, 1f, a)
            shapes.circle(x, y, 1.2f, 6)
        }
    }

    fun road() {
        shapes.setColor(0.02f, 0.03f, 0.09f, 0.95f)
        shapes.rect(66f, 0f, 348f, 430f)
        shapes.setColor(cyan.r, cyan.g, cyan.b, 0.20f)
        shapes.rect(66f, 0f, 3f, 430f)
        shapes.rect(411f, 0f, 3f, 430f)
        shapes.setColor(purple.r, purple.g, purple.b, 0.22f)
        shapes.rect(181f, 0f, 2f, 430f)
        shapes.rect(297f, 0f, 2f, 430f)
        for (i in 0..11) {
            val y = i * 43f + (worldTime * 240f % 43f)
            shapes.setColor(cyan.r, cyan.g, cyan.b, 0.18f)
            shapes.rect(72f, y, 336f, 1.4f)
            shapes.setColor(white.r, white.g, white.b, 0.10f)
            shapes.rect(118f, y + 7f, 4f, 12f)
            shapes.rect(238f, y + 7f, 4f, 12f)
            shapes.rect(358f, y + 7f, 4f, 12f)
        }
    }

    fun playerRunner(laneX: Float, y: Float, jumpHeight: Float, isSliding: Boolean, runPhase: Float) {
        val bob = if (jumpHeight > 0f) jumpHeight else sin(worldTime * 10f).toFloat() * 2.2f
        val phase = sin(runPhase).toFloat()
        val phaseOpp = sin(runPhase + Math.PI).toFloat()
        val baseY = y - 3f + bob

        shapes.setColor(cyan.r, cyan.g, cyan.b, 0.12f)
        shapes.ellipse(laneX - 34f, y - 32f, 68f, 16f)
        if (isSliding) {
            shapes.setColor(0.10f, 0.90f, 1f, 0.18f)
            shapes.rect(laneX - 29f, baseY - 5f, 58f, 18f)
            shapes.setColor(0.06f, 0.11f, 0.24f, 1f)
            shapes.rect(laneX - 22f, baseY - 2f, 44f, 12f)
            shapes.setColor(white)
            shapes.circle(laneX + 20f, baseY + 11f, 8f, 18)
            shapes.setColor(cyan)
            shapes.circle(laneX + 20f, baseY + 11f, 8f, 18)
            shapes.setColor(0.07f, 0.14f, 0.28f, 1f)
            shapes.circle(laneX + 20f, baseY + 11f, 6f, 18)
            shapes.setColor(pink)
            shapes.rect(laneX - 3f, baseY + 3f, 18f, 3.5f)
            shapes.setColor(cyan)
            shapes.rectLine(laneX - 4f, baseY + 2f, laneX - 20f, baseY - 5f, 3f)
            shapes.rectLine(laneX + 2f, baseY + 1f, laneX - 18f, baseY - 8f, 3f)
            shapes.rectLine(laneX + 12f, baseY + 1f, laneX + 27f, baseY - 2f, 3f)
            shapes.rectLine(laneX + 15f, baseY + 2f, laneX + 29f, baseY + 9f, 3f)
            return
        }

        shapes.setColor(0.09f, 0.88f, 1f, 0.18f)
        shapes.rect(laneX - 18f, baseY + 4f, 36f, 34f)
        shapes.setColor(0.06f, 0.11f, 0.24f, 1f)
        shapes.rect(laneX - 13f, baseY + 8f, 26f, 28f)
        shapes.setColor(cyan)
        outline(laneX - 13f, baseY + 8f, 26f, 28f, 2f)

        shapes.setColor(white)
        shapes.circle(laneX, baseY + 48f, 10.5f, 20)
        shapes.setColor(cyan)
        shapes.circle(laneX, baseY + 48f, 10f, 20)
        shapes.setColor(0.06f, 0.12f, 0.26f, 1f)
        shapes.circle(laneX, baseY + 48f, 7.5f, 20)
        shapes.setColor(pink)
        shapes.rect(laneX - 6f, baseY + 21f, 12f, 4f)

        shapes.setColor(cyan)
        shapes.rectLine(laneX - 12f, baseY + 30f, laneX - 22f, baseY + 18f + phase * 7f, 3.2f)
        shapes.rectLine(laneX + 12f, baseY + 30f, laneX + 20f, baseY + 17f + phaseOpp * 7f, 3.2f)
        shapes.rectLine(laneX - 5f, baseY + 8f, laneX - 13f, baseY - 18f + phaseOpp * 10f, 3.6f)
        shapes.rectLine(laneX + 5f, baseY + 8f, laneX + 15f, baseY - 18f + phase * 10f, 3.6f)

        shapes.setColor(pink)
        shapes.rectLine(laneX - 13f, baseY - 17f + phaseOpp * 10f, laneX - 19f, baseY - 26f + phaseOpp * 12f, 4f)
        shapes.rectLine(laneX + 15f, baseY - 17f + phase * 10f, laneX + 21f, baseY - 26f + phase * 12f, 4f)
    }

    fun objectShape(kind: RunSession.Kind, lane: Int, y: Float) {
        val x = (120 + lane * 120).toFloat()
        when (kind) {
            RunSession.Kind.ORB -> {
                shapes.setColor(0.16f, 1f, 0.93f, 0.18f)
                shapes.circle(x, y, 26f, 20)
                shapes.setColor(cyan)
                shapes.circle(x, y, 14f, 20)
                shapes.setColor(0.05f, 0.22f, 0.33f, 1f)
                shapes.circle(x, y, 8.5f, 20)
                shapes.setColor(white)
                shapes.circle(x, y, 3f, 10)
            }
            RunSession.Kind.BLOCK -> {
                shapes.setColor(1f, 0.15f, 0.3f, 0.14f)
                shapes.rect(x - 40f, y - 32f, 80f, 64f)
                shapes.setColor(0.25f, 0.05f, 0.14f, 1f)
                shapes.rect(x - 30f, y - 24f, 60f, 48f)
                shapes.setColor(pink)
                outline(x - 30f, y - 24f, 60f, 48f, 3f)
                shapes.rect(x - 9f, y - 4f, 18f, 8f)
            }
            RunSession.Kind.LOW_BARRIER -> {
                shapes.setColor(lime.r, lime.g, lime.b, 0.22f)
                shapes.rect(x - 41f, y - 20f, 82f, 40f)
                shapes.setColor(lime)
                shapes.rect(x - 34f, y - 12f, 68f, 16f)
                shapes.rect(x - 34f, y + 6f, 68f, 5f)
                shapes.setColor(0.08f, 0.18f, 0.08f, 1f)
                shapes.rect(x - 28f, y - 8f, 56f, 8f)
            }
            RunSession.Kind.HIGH_BARRIER -> {
                shapes.setColor(pink)
                shapes.rect(x - 38f, y + 15f, 76f, 7f)
                shapes.rect(x - 38f, y - 20f, 5f, 39f)
                shapes.rect(x + 33f, y - 20f, 5f, 39f)
                shapes.setColor(pink.r, pink.g, pink.b, 0.18f)
                shapes.rect(x - 28f, y - 12f, 56f, 18f)
            }
        }
    }

    fun hudBar(progress: Float) {
        shapes.setColor(0f, 0f, 0.08f, 0.80f)
        shapes.rect(0f, 710f, 480f, 90f)
        shapes.setColor(0.06f, 0.08f, 0.15f, 1f)
        shapes.rect(20f, 712f, 260f, 6f)
        shapes.setColor(cyan)
        shapes.rect(20f, 712f, 260f * progress.coerceIn(0f, 1f), 6f)
        button(408f, 733f, 48f, 44f, purple)
        shapes.setColor(cyan)
        shapes.rect(427f, 745f, 4f, 19f)
        shapes.rect(436f, 745f, 4f, 19f)
    }

    fun controlPad(actionHint: Enum<*>? = null, showPulse: Boolean = false) {
        val pulse = if (showPulse) 0.08f + 0.06f * (1f + sin(worldTime * 4f)) else 0.08f
        controlButton(28f, 25f, 92f, 92f, cyan, pulse, actionHint?.name == "NONE")
        controlButton(134f, 25f, 92f, 92f, cyan, pulse, actionHint?.name == "NONE")
        controlButton(254f, 25f, 92f, 92f, lime, if (actionHint?.name == "JUMP") 0.20f else pulse, actionHint?.name == "JUMP")
        controlButton(360f, 25f, 92f, 92f, pink, if (actionHint?.name == "SLIDE") 0.20f else pulse, actionHint?.name == "SLIDE")

        shapes.setColor(white)
        shapes.rectLine(64f, 71f, 47f, 71f, 5f)
        shapes.rectLine(47f, 71f, 57f, 80f, 5f)
        shapes.rectLine(47f, 71f, 57f, 62f, 5f)

        shapes.rectLine(182f, 71f, 199f, 71f, 5f)
        shapes.rectLine(199f, 71f, 189f, 80f, 5f)
        shapes.rectLine(199f, 71f, 189f, 62f, 5f)

        shapes.rectLine(300f, 52f, 300f, 86f, 5f)
        shapes.rectLine(300f, 86f, 289f, 75f, 5f)
        shapes.rectLine(300f, 86f, 311f, 75f, 5f)

        shapes.rectLine(406f, 90f, 406f, 56f, 5f)
        shapes.rectLine(406f, 56f, 395f, 67f, 5f)
        shapes.rectLine(406f, 56f, 417f, 67f, 5f)
    }

    fun controlLabels() {
        text("LEFT", 74f, 41f, 0.78f, muted, true)
        text("RIGHT", 180f, 41f, 0.78f, muted, true)
        text("JUMP", 300f, 41f, 0.78f, white, true)
        text("SLIDE", 406f, 41f, 0.78f, white, true)
    }

    fun tutorialCard() {
        shapes.setColor(0.02f, 0.04f, 0.10f, 0.82f)
        shapes.rect(52f, 608f, 376f, 74f)
        shapes.setColor(cyan.r, cyan.g, cyan.b, 0.8f)
        outline(52f, 608f, 376f, 74f, 2f)
    }

    fun tutorialText() {
        text("Controls are now easier: tap buttons or swipe.", 240f, 655f, 1.0f, white, true)
        text("Green = jump  •  Pink = slide", 240f, 629f, 0.95f, muted, true)
    }

    fun overlay() {
        shapes.setColor(0.01f, 0.01f, 0.05f, 0.92f)
        shapes.rect(0f, 0f, 480f, 800f)
    }

    fun bigPanel(x: Float, y: Float, w: Float, h: Float) {
        shapes.setColor(0.05f, 0.07f, 0.16f, 0.97f)
        shapes.rect(x, y, w, h)
        shapes.setColor(cyan.r, cyan.g, cyan.b, 0.65f)
        outline(x, y, w, h, 2.5f)
    }

    fun button(x: Float, y: Float, w: Float, h: Float, accent: Color = cyan) {
        shapes.setColor(accent.r, accent.g, accent.b, 0.12f)
        shapes.rect(x - 6f, y - 6f, w + 12f, h + 12f)
        shapes.setColor(0.06f, 0.08f, 0.17f, 1f)
        shapes.rect(x, y, w, h)
        shapes.setColor(accent.r, accent.g, accent.b, 0.95f)
        outline(x, y, w, h, 2f)
        shapes.rect(x + 4f, y + h - 5f, w - 8f, 2f)
    }

    private fun controlButton(x: Float, y: Float, w: Float, h: Float, accent: Color, glow: Float, emphasized: Boolean) {
        shapes.setColor(accent.r, accent.g, accent.b, glow)
        shapes.rect(x - 4f, y - 4f, w + 8f, h + 8f)
        shapes.setColor(0.05f, 0.07f, 0.14f, 0.95f)
        shapes.rect(x, y, w, h)
        shapes.setColor(accent)
        outline(x, y, w, h, if (emphasized) 3.2f else 2f)
    }

    fun labelButton(label: String, x: Float, y: Float, w: Float, h: Float, scale: Float = 1.65f) {
        text(label, x + w / 2f, y + h / 2f + 7f, scale, white, true)
    }

    fun logo() {
        shapes.setColor(cyan.r, cyan.g, cyan.b, 0.08f)
        shapes.rect(54f, 534f, 372f, 164f)
        shapes.setColor(cyan)
        shapes.rect(74f, 679f, 332f, 3f)
        shapes.setColor(purple)
        shapes.rect(74f, 548f, 332f, 3f)
        shapes.setColor(pink)
        shapes.rectLine(102f, 578f, 102f, 650f, 8f)
        shapes.rectLine(102f, 650f, 150f, 578f, 8f)
        shapes.rectLine(150f, 578f, 150f, 650f, 8f)
    }

    fun statCard(x: Float, y: Float, w: Float, h: Float, accent: Color = cyan) {
        shapes.setColor(0.05f, 0.07f, 0.16f, 0.96f)
        shapes.rect(x, y, w, h)
        shapes.setColor(accent.r, accent.g, accent.b, 0.75f)
        outline(x, y, w, h, 2f)
    }

    fun orbParticles(x: Float, y: Float, remaining: Float) {
        val progress = 1f - remaining / 0.40f
        for (i in 0..11) {
            val angle = (i / 12f) * 6.28318f
            val radius = progress * 75f
            shapes.setColor(0.15f, 0.96f, 1f, (1f - progress) * 0.9f)
            shapes.circle(x + cos(angle) * radius, y + sin(angle) * radius, (3f - progress * 2f).coerceAtLeast(1f), 7)
        }
    }

    fun cyan(): Color = cyan
    fun pink(): Color = pink
    fun purple(): Color = purple
    fun muted(): Color = muted
    fun white(): Color = white
    fun lime(): Color = lime

    private fun outline(x: Float, y: Float, w: Float, h: Float, t: Float) {
        shapes.rect(x, y, w, t)
        shapes.rect(x, y + h - t, w, t)
        shapes.rect(x, y, t, h)
        shapes.rect(x + w - t, y, t, h)
    }

    override fun dispose() {
        font.dispose()
        shapes.dispose()
        batch.dispose()
    }
}
