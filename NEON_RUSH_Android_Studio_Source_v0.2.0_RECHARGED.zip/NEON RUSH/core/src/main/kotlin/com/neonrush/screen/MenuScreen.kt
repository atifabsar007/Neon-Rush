package com.neonrush.screen

import com.neonrush.NeonRushGame

class MenuScreen(game: NeonRushGame) : BaseScreen(game) {
    override fun render(delta: Float) {
        prepare(delta)
        painter.beginShapes()
        painter.backdrop()
        painter.logo()
        painter.statCard(64f, 458f, 352f, 64f, painter.lime())
        painter.button(80f, 360f, 320f, 72f)
        painter.button(80f, 272f, 320f, 62f, painter.purple())
        painter.button(80f, 192f, 320f, 62f, painter.pink())
        painter.endShapes()

        painter.beginText()
        painter.text("NEON", 276f, 639f, 3.7f, painter.cyan(), true)
        painter.text("RUSH", 246f, 585f, 3.8f, painter.white(), true)
        painter.text("Runner Recharged Edition", 240f, 516f, 1.18f, painter.white(), true)
        painter.text("Cleaner visuals. Better controls. Smoother run.", 240f, 490f, 0.98f, painter.muted(), true)
        painter.text("BEST SCORE  ${game.saves.bestScore}", 240f, 499f, 1.2f, painter.lime(), true)
        painter.labelButton("PLAY", 80f, 360f, 320f, 72f, 2.1f)
        painter.labelButton("SETTINGS", 80f, 272f, 320f, 62f)
        painter.labelButton("HOW TO PLAY", 80f, 192f, 320f, 62f)
        painter.text("OFFLINE ARCADE  •  V0.2.0", 240f, 101f, 1.0f, painter.muted(), true)
        painter.text("Tap PLAY and use buttons or swipe controls.", 240f, 74f, 0.95f, painter.white(), true)
        painter.endText()

        tapped()?.let { pos ->
            when {
                inRect(pos, 80f, 360f, 320f, 72f) -> game.navigate(PlayScreen(game))
                inRect(pos, 80f, 272f, 320f, 62f) -> game.navigate(SettingsScreen(game))
                inRect(pos, 80f, 192f, 320f, 62f) -> game.navigate(HowToPlayScreen(game))
            }
        }
    }
}
