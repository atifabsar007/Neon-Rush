package com.neonrush.screen

import com.neonrush.NeonRushGame

class HowToPlayScreen(game: NeonRushGame) : BaseScreen(game) {
    override fun render(delta: Float) {
        prepare(delta)
        painter.beginShapes()
        painter.backdrop()
        painter.bigPanel(38f, 120f, 404f, 570f)
        painter.button(80f, 140f, 320f, 66f)
        painter.endShapes()
        painter.beginText()
        painter.text("HOW TO PLAY", 240f, 648f, 2.5f, painter.cyan(), true)
        painter.text("LEFT / RIGHT", 240f, 575f, 1.55f, painter.white(), true)
        painter.text("Tap the control buttons or swipe sideways", 240f, 547f, 1.0f, painter.muted(), true)
        painter.text("JUMP", 240f, 485f, 1.55f, painter.lime(), true)
        painter.text("Use the green button or swipe up", 240f, 457f, 1.0f, painter.muted(), true)
        painter.text("SLIDE", 240f, 396f, 1.55f, painter.pink(), true)
        painter.text("Use the pink button or swipe down", 240f, 368f, 1.0f, painter.muted(), true)
        painter.text("AVOID CRATES  •  JUMP GREEN BARS  •  SLIDE UNDER PINK BARS", 240f, 302f, 0.90f, painter.white(), true)
        painter.text("Collect energy orbs to boost your score.", 240f, 271f, 1.0f, painter.cyan(), true)
        painter.text("Desktop controls: A/D or arrows, Space/W, S, P", 240f, 226f, 0.88f, painter.muted(), true)
        painter.labelButton("GOT IT", 80f, 140f, 320f, 66f)
        painter.endText()
        tapped()?.let { pos -> if (inRect(pos, 80f, 140f, 320f, 66f)) game.navigate(MenuScreen(game)) }
    }
}
