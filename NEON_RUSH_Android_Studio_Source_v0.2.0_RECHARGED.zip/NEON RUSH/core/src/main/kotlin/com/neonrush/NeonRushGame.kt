package com.neonrush

import com.badlogic.gdx.Game
import com.badlogic.gdx.Screen
import com.neonrush.render.NeonPainter
import com.neonrush.screen.MenuScreen
import com.neonrush.service.AudioManager
import com.neonrush.service.SaveRepository

class NeonRushGame : Game() {
    lateinit var painter: NeonPainter
        private set
    lateinit var saves: SaveRepository
        private set
    lateinit var audio: AudioManager
        private set

    override fun create() {
        painter = NeonPainter()
        saves = SaveRepository()
        audio = AudioManager(saves)
        navigate(MenuScreen(this))
        audio.syncMusic()
    }

    /** Screen lifecycle is centralized so disposed screens are never reused. */
    fun navigate(next: Screen) {
        val previous = screen
        setScreen(next)
        previous?.dispose()
    }

    override fun pause() {
        super.pause()
        audio.onPause()
    }

    override fun resume() {
        super.resume()
        audio.onResume()
    }

    override fun dispose() {
        screen?.dispose()
        super.dispose()
        audio.dispose()
        painter.dispose()
    }
}
