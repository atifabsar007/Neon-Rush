package com.neonrush.screen

import com.neonrush.NeonRushGame

class GameOverScreen(
    game: NeonRushGame,
    private val finalScore: Int,
    private val orbs: Int,
    private val newRecord: Boolean
) : BaseScreen(game) {
    override fun render(delta: Float) {
        prepare(delta)
        painter.beginShapes()
        painter.backdrop()
        painter.overlay()
        painter.bigPanel(46f, 180f, 388f, 430f)
        painter.button(78f, 300f, 324f, 70f)
        painter.button(78f, 212f, 324f, 64f, painter.purple())
        painter.endShapes()
        painter.beginText()
        painter.text("RUN OVER", 240f, 568f, 3.0f, painter.pink(), true)
        painter.text("FINAL SCORE", 240f, 517f, 1.2f, painter.muted(), true)
        painter.text("$finalScore", 240f, 471f, 3.4f, painter.white(), true)
        painter.text("BEST ${game.saves.bestScore}", 240f, 428f, 1.35f, painter.cyan(), true)
        painter.text("ENERGY ORBS  $orbs", 240f, 391f, 1.2f, painter.white(), true)
        if (newRecord) painter.text("NEW PERSONAL RECORD!", 240f, 358f, 1.1f, painter.lime(), true)
        painter.labelButton("RETRY", 78f, 300f, 324f, 70f, 1.9f)
        painter.labelButton("MAIN MENU", 78f, 212f, 324f, 64f)
        painter.endText()
        tapped()?.let { pos ->
            when {
                inRect(pos, 78f, 300f, 324f, 70f) -> game.navigate(PlayScreen(game))
                inRect(pos, 78f, 212f, 324f, 64f) -> game.navigate(MenuScreen(game))
            }
        }
    }
}
