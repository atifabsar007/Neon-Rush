plugins {
    id("com.android.application") version "8.10.1" apply false
    kotlin("android") version "2.2.21" apply false
    kotlin("jvm") version "2.2.21" apply false
}
